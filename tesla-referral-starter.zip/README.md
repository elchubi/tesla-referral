# Tesla Referral

Sitio web multilingüe con geolocalización para promocionar código de referido de Tesla.

Este repositorio será usado junto con Cloudflare Pages, GitHub Actions y APIs de IA para scraping y edición de imágenes.
